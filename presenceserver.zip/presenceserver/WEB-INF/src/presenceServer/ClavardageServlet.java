// To save as "<CATALINA_HOME>\webapps\helloservlet\WEB-INF\src\mypkg\HelloServlet.java"
package presenceServer;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.HashMap;
import java.net.InetAddress; 
import java.util.Iterator;
import java.util.Set;
import java.util.Enumeration;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.net.SocketException;

/*
HOW TO USE :
To request online users : (GET HTTP request)
display="true" => graphical display to be used in an internet browser.
display=other thing => textual answer on a particular syntax
pseudo="pseudoOfTheUser"
type="connect" => The user is connecting
type="deconnect" => The user is deconnecting 
type="change" => The user is changing its pseudo
type="info" => The user wants the list of online users
type="isfree" => The user wants to know if a pseudo is available
*/
public class ClavardageServlet extends HttpServlet {
		
   private HashMap<String,String> onlineUsers = new HashMap<String,String>();
   private int nbRequests = 0;

  public static InetAddress getLocalAddress()
  {
    try {
    Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
    while( ifaces.hasMoreElements() )
    {
      NetworkInterface iface = ifaces.nextElement();
      Enumeration<InetAddress> addresses = iface.getInetAddresses();

      while( addresses.hasMoreElements() )
      {
        InetAddress addr = addresses.nextElement();
        if( addr instanceof Inet4Address && !addr.isLoopbackAddress() )
        {
          return addr;
        }
      }
    }

    return null;
	} catch(SocketException ex) {
		ex.printStackTrace();
		return null;
	}
  }
	
   @Override
   public void doGet(HttpServletRequest request, HttpServletResponse response)
               throws IOException, ServletException {
      nbRequests++;
      // Set the response message's MIME type
      response.setContentType("text/html;charset=UTF-8");
      // Allocate a output writer to write the response message into the network socket
      PrintWriter out = response.getWriter();
      try {
         String display;
	 try {
	 	display = request.getParameter("display").replace("\"","");;
	 }
	 catch(Exception e) {
		display="false";
	 }
	 String type = request.getParameter("type").replace("\"","");;
	 String pseudo = request.getParameter("pseudo").replace("\"","");
	 /* PERFORM OPERATIONS ON THE LIST OF USERS */
	 if(type.equals("connect")) {
	        if(InetAddress.getByName(request.getRemoteAddr()).isLoopbackAddress()) { // So that other users can join localhost user by using a not-loopback address
			InetAddress adr = getLocalAddress();
			if(adr!=null) {
				onlineUsers.put(pseudo,adr.toString().substring(1));
			}
			else {
				onlineUsers.put(pseudo,request.getRemoteAddr());
			}
		}
		else {
			onlineUsers.put(pseudo,request.getRemoteAddr());
		}
	 }
	 if(type.equals("deconnect")) {
		onlineUsers.remove(pseudo);
	 }
	 if(type.equals("change")) {
		String hostAddr = request.getRemoteAddr();
		Set<String> usersOnTable = onlineUsers.keySet();
		Iterator<String> it = usersOnTable.iterator();
		String theUser = "shouldchange";
		while(it.hasNext()) {	
			String aUser = it.next();
			if((onlineUsers.get(aUser)) != null) {	
				if((onlineUsers.get(aUser)).equals(hostAddr)) {	
					theUser = aUser;
				}
			}
		}
	 	System.out.println(theUser + "addr = " + (onlineUsers.get(theUser)).toString() );									
		onlineUsers.remove(theUser);
		onlineUsers.put(pseudo,hostAddr);
	 }
	 /* BUILD THE RESPONSE */
	 if(display.equals("true")) { // Write the response message, in an HTML page	 
		 out.println("<!DOCTYPE html>");
		 out.println("<html><head>");
		 out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
		 out.println("<title>Presence Server</title></head>");
		 out.println("<body>");
		 out.println("<h1>Presence Server Graphical Display </h1>");
		 out.println("<p>Server address: " + InetAddress.getLocalHost()  + "</p>");
		 out.println("<p>Remote Address: " + request.getRemoteAddr() + "</p>");
		 out.println("<p>type = " + type + "</p>");
		 out.println("<p>pseudo = " + pseudo + "</p>");
		 out.println("<p>nbRequests = " + nbRequests + "</p>");
		 out.println("<p>OnlineUsers:</p>");
		 out.println("<ul>");
		 for(String aUser:onlineUsers.keySet()) {
			out.println("<li>" + aUser + " is online (@" + onlineUsers.get(aUser).toString() + ")</li>");
		 }
		 out.println("</ul>");
		 out.println("</body>");
		 out.println("</html>");
	 }
	 else {
	 	out.print("SERVER_REPLY:"); // Write the response message, in a particular syntax
		if(type.equals("connect")) {
			out.println("Welcome, " + pseudo);
		}
		if(type.equals("deconnect")) {
			out.println("Bye, " + pseudo);
		}
		if(type.equals("change")) {
			out.println("Pseudo change OK, " + pseudo);
		}
		if(type.equals("info")) {
			for(String aUser:onlineUsers.keySet()) {
				out.print(aUser + "@" + onlineUsers.get(aUser).toString() + ";;");
			}
		}
		if(type.equals("isfree")) {
			if(onlineUsers.containsKey(pseudo)) {
				out.println("NO");
			} else {
				out.println("YES");
			}
		}
	 }
	 } finally {
		 out.flush();
		 out.close();  // Always close the output writer
	 }
   }
}


